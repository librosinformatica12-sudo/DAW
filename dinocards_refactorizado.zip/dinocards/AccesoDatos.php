<?php
/**
 * AccesoDatos.php
 * ------------------------------------------------------------------
 * CAPA DE ACCESO A DATOS de DinoCards.
 *
 * Este es el ÚNICO archivo del proyecto que habla con MySQL: aquí están
 * la conexión y todas las consultas. Ningún otro .php (páginas,
 * backend.php, funciones.php) usa mysqli ni escribe SQL: solo llama a
 * las funciones de este archivo.
 *
 *   index.php / inicio.php / ...  ->  backend.php  ->  AccesoDatos.php  ->  MySQL
 *
 * Todas las consultas son preparadas (nunca se concatenan datos del
 * usuario dentro del SQL).
 * ------------------------------------------------------------------
 */

// ==================================================================
// CONFIGURACIÓN DE LA CONEXIÓN  (edita aquí tus datos de MySQL/XAMPP)
// También se pueden definir como variables de entorno DINOCARDS_DB_*.
// ==================================================================
function configuracionBD(): array
{
    $env = static function (string $nombre, $defecto) {
        $valor = getenv($nombre);
        return ($valor === false || $valor === '') ? $defecto : $valor;
    };

    return [
        'host'     => $env('DINOCARDS_DB_HOST', '127.0.0.1'),
        'port'     => (int) $env('DINOCARDS_DB_PORT', 3306),
        'database' => $env('DINOCARDS_DB_NAME', 'dinocards'),
        'username' => $env('DINOCARDS_DB_USER', 'oscar'),
        'password' => $env('DINOCARDS_DB_PASS', '1234'),
        'charset'  => 'utf8mb4',
    ];
}

// ==================================================================
// CONEXIÓN Y UTILIDADES INTERNAS
// ==================================================================

/** Registra el detalle técnico en el log y muestra un mensaje genérico. */
function falloAccesoDatos(string $detalle): void
{
    error_log('[DinoCards] ' . $detalle);

    if (!headers_sent()) {
        http_response_code(500);
    }
    echo 'No se pudo completar la operación. Inténtalo de nuevo.';
    exit;
}

/** Devuelve la conexión mysqli (se abre la primera vez que se necesita). */
function conexionBD(): mysqli
{
    static $conexion = null;

    if ($conexion instanceof mysqli) {
        return $conexion;
    }

    // Los errores de MySQL se lanzan como excepciones (mysqli_sql_exception).
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $cfg = configuracionBD();

    try {
        $conexion = new mysqli(
            $cfg['host'],
            $cfg['username'],
            $cfg['password'],
            $cfg['database'],
            $cfg['port']
        );
        $conexion->set_charset($cfg['charset']);
    } catch (mysqli_sql_exception $e) {
        falloAccesoDatos('Error de conexión: ' . $e->getMessage());
    }

    return $conexion;
}

/**
 * Compatibilidad: la base de datos antigua guarda las imágenes como
 * "img/..." y la carpeta ahora se llama "res/". Así funcionan las dos.
 */
function rutaRecurso($ruta)
{
    return is_string($ruta) ? preg_replace('#^img/#', 'res/', $ruta) : $ruta;
}

/**
 * Ejecuta una consulta preparada y devuelve TODAS las filas.
 *
 * @param string $sql    SQL con marcadores ?
 * @param string $tipos  Tipos de bind_param ("i", "ss", ...). Vacío si no hay parámetros.
 * @param array  $params Valores, en el mismo orden que los ?.
 */
function bdFilas(string $sql, string $tipos = '', array $params = []): array
{
    $consulta = conexionBD()->prepare($sql);

    try {
        if ($tipos !== '') {
            $consulta->bind_param($tipos, ...$params);
        }
        $consulta->execute();
        $filas = $consulta->get_result()->fetch_all(MYSQLI_ASSOC);
    } finally {
        $consulta->close();
    }

    foreach ($filas as $i => $fila) {
        if (isset($fila['imagen_url'])) {
            $filas[$i]['imagen_url'] = rutaRecurso($fila['imagen_url']);
        }
    }

    return $filas;
}

/** Igual que bdFilas(), pero devuelve solo la primera fila (o null). */
function bdFila(string $sql, string $tipos = '', array $params = []): ?array
{
    $filas = bdFilas($sql, $tipos, $params);

    return $filas[0] ?? null;
}

/** Ejecuta INSERT / UPDATE / DELETE preparado. Devuelve las filas afectadas. */
function bdEjecutar(string $sql, string $tipos = '', array $params = []): int
{
    $consulta = conexionBD()->prepare($sql);

    try {
        if ($tipos !== '') {
            $consulta->bind_param($tipos, ...$params);
        }
        $consulta->execute();
        $afectadas = $consulta->affected_rows;
    } finally {
        $consulta->close();
    }

    return (int) $afectadas;
}

// ==================================================================
// USUARIOS  (tabla `usuarios`)
// ==================================================================

/**
 * Datos públicos del usuario, o null si no existe.
 * Nunca incluye password_hash: las páginas no lo necesitan.
 */
function obtenerUsuarioPorId(int $usuario_id): ?array
{
    return bdFila(
        "SELECT id, username, email, fecha_registro, ultima_obtencion, carta_prueba
         FROM usuarios WHERE id = ?",
        "i",
        [$usuario_id]
    );
}

/** Fecha (string) de la última vez que abrió el sobre del día, o null. */
function obtenerUltimaObtencion(int $usuario_id): ?string
{
    $fila = bdFila("SELECT ultima_obtencion FROM usuarios WHERE id = ?", "i", [$usuario_id]);

    return $fila["ultima_obtencion"] ?? null;
}

/**
 * Busca una cuenta por correo o por nombre de usuario para el login.
 * Devuelve ['id', 'username', 'password_hash'] o null.
 */
function obtenerUsuarioParaLogin(string $identificador): ?array
{
    return bdFila(
        "SELECT id, username, password_hash FROM usuarios
         WHERE email = ? OR username = ?
         LIMIT 1",
        "ss",
        [$identificador, $identificador]
    );
}

/** Guarda un nuevo hash de contraseña (p. ej. al migrar un md5 antiguo). */
function actualizarPasswordHash(int $usuario_id, string $hash): bool
{
    return bdEjecutar(
        "UPDATE usuarios SET password_hash = ? WHERE id = ?",
        "si",
        [$hash, $usuario_id]
    ) > 0;
}

/** ¿Existe ya un usuario con ese nombre o ese correo? */
function existeUsuarioOEmail(string $username, string $email): bool
{
    return bdFila(
        "SELECT id FROM usuarios WHERE username = ? OR email = ? LIMIT 1",
        "ss",
        [$username, $email]
    ) !== null;
}

/**
 * Crea un usuario. Devuelve false si no se pudo (p. ej. nombre o correo
 * duplicados por una petición simultánea: los índices UNIQUE lo impiden).
 */
function crearUsuario(string $username, string $email, string $password_hash): bool
{
    try {
        return bdEjecutar(
            "INSERT INTO usuarios (username, email, password_hash, fecha_registro)
             VALUES (?, ?, ?, NOW())",
            "sss",
            [$username, $email, $password_hash]
        ) === 1;
    } catch (mysqli_sql_exception $e) {
        error_log("[DinoCards] crearUsuario falló: " . $e->getMessage());
        return false;
    }
}

/** Marca ahora como la última vez que se abrió el sobre del día. */
function marcarUltimaObtencion(int $usuario_id): void
{
    bdEjecutar("UPDATE usuarios SET ultima_obtencion = NOW() WHERE id = ?", "i", [$usuario_id]);
}

/** Marca ahora como la última vez que se abrió el sobre de prueba. */
function marcarCartaPrueba(int $usuario_id): void
{
    bdEjecutar("UPDATE usuarios SET carta_prueba = NOW() WHERE id = ?", "i", [$usuario_id]);
}

// ==================================================================
// COLECCIONES  (tabla `colecciones`: cartas que tiene cada usuario)
// ==================================================================

/** Añade un dinosaurio a la colección de un usuario. */
function anadirCarta(int $usuario_id, int $dinosaurio_id): void
{
    bdEjecutar(
        "INSERT INTO colecciones (usuario_id, dinosaurio_id, fecha_adquisicion)
         VALUES (?, ?, NOW())",
        "ii",
        [$usuario_id, $dinosaurio_id]
    );
}

/**
 * Añade varias cartas de golpe dentro de una transacción: o entran todas
 * o no entra ninguna (evita sobres a medias si algo falla).
 *
 * @param int[] $dinosaurio_ids
 */
function anadirCartas(int $usuario_id, array $dinosaurio_ids): void
{
    $conexion = conexionBD();
    $conexion->begin_transaction();

    try {
        foreach ($dinosaurio_ids as $dinosaurio_id) {
            anadirCarta($usuario_id, (int) $dinosaurio_id);
        }
        $conexion->commit();
    } catch (Throwable $e) {
        $conexion->rollback();
        throw $e;
    }
}

/**
 * Lista de dinosaurio_id que posee un usuario (se conservan los repetidos).
 *
 * @return int[]
 */
function obtenerIdsColeccion(int $usuario_id): array
{
    $filas = bdFilas("SELECT dinosaurio_id FROM colecciones WHERE usuario_id = ?", "i", [$usuario_id]);

    return array_map(static function (array $fila): int {
        return (int) $fila["dinosaurio_id"];
    }, $filas);
}

/** Resumen de la colección: ['cartas' => int, 'especies' => int]. */
function resumenColeccion(int $usuario_id): array
{
    $fila = bdFila(
        "SELECT COUNT(*) AS total, COUNT(DISTINCT dinosaurio_id) AS especies
         FROM colecciones WHERE usuario_id = ?",
        "i",
        [$usuario_id]
    );

    return [
        'cartas'   => (int) ($fila["total"] ?? 0),
        'especies' => (int) ($fila["especies"] ?? 0),
    ];
}

/** Últimas cartas obtenidas por un usuario (más recientes primero). */
function ultimasCartas(int $usuario_id, int $limite = 6): array
{
    $limite = max(1, min(50, $limite));

    return bdFilas(
        "SELECT d.*
         FROM colecciones c
         INNER JOIN dinosaurios d ON d.id = c.dinosaurio_id
         WHERE c.usuario_id = ?
         ORDER BY c.fecha_adquisicion DESC
         LIMIT ?",
        "ii",
        [$usuario_id, $limite]
    );
}

// ==================================================================
// DINOSAURIOS  (tabla `dinosaurios`: catálogo)
// ==================================================================

/** Número total de dinosaurios del catálogo. */
function contarDinosaurios(): int
{
    $fila = bdFila("SELECT COUNT(*) AS total FROM dinosaurios");

    return (int) ($fila["total"] ?? 0);
}

/** Todo el catálogo, ordenado por id (lo usa la DinoPedia). */
function obtenerTodosLosDinosaurios(): array
{
    return bdFilas("SELECT * FROM dinosaurios ORDER BY id");
}

/** Devuelve un dinosaurio al azar, o null si no hay ninguno. */
function dinosaurioAleatorio(): ?array
{
    return bdFila("SELECT * FROM dinosaurios ORDER BY RAND() LIMIT 1");
}

/** Devuelve N dinosaurios al azar (sin repetir), o [] si no hay ninguno. */
function dinosauriosAleatorios(int $n): array
{
    $n = max(1, min(50, $n));

    return bdFilas("SELECT * FROM dinosaurios ORDER BY RAND() LIMIT ?", "i", [$n]);
}

/**
 * Devuelve los dinosaurios indicados indexados por su id:
 *   [ id => [fila de dinosaurios] ]
 *
 * @param array $ids Lista de ids (se normalizan a enteros sin repetir).
 */
function dinosauriosPorIds(array $ids): array
{
    $ids = array_values(array_unique(array_map('intval', array_filter($ids, 'is_numeric'))));
    if (!$ids) {
        return [];
    }

    $marcadores = implode(",", array_fill(0, count($ids), "?"));
    $filas = bdFilas(
        "SELECT * FROM dinosaurios WHERE id IN ($marcadores)",
        str_repeat("i", count($ids)),
        $ids
    );

    $mapa = [];
    foreach ($filas as $fila) {
        $mapa[(int) $fila["id"]] = $fila;
    }

    return $mapa;
}
