<?php
/* ============================================================
   backend.php
   ------------------------------------------------------------------
   Controlador único de DinoCards. Se llama con ?accion=...

     backend.php?accion=login          (POST, responde JSON)
     backend.php?accion=registro       (POST, responde JSON)
     backend.php?accion=logout         (redirige a index.php)
     backend.php?accion=carta-diaria   (POST, redirige a inicio.php)
     backend.php?accion=sobre-prueba   (POST, redirige a inicio.php)

   Aquí está la lógica de negocio (comprobar datos, esperas, elegir
   cartas al azar). NO hay SQL: todo acceso a MySQL se hace llamando a
   las funciones de AccesoDatos.php.
   ============================================================ */

require_once __DIR__ . '/funciones.php';
require_once __DIR__ . '/AccesoDatos.php';

// ------------------------------------------------------------
// Utilidades de respuesta
// ------------------------------------------------------------

/** Envía una respuesta JSON { ok, mensaje, ... } y termina. */
function responderJson(bool $ok, string $mensaje, array $extra = []): void
{
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode(
        array_merge(['ok' => $ok, 'mensaje' => $mensaje], $extra),
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

/** Redirige y termina. */
function redirigir(string $pagina): void
{
    header('Location: ' . $pagina);
    exit;
}

/** Para los endpoints JSON: exige POST y token CSRF válido. */
function exigirPostJson(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405);
        responderJson(false, 'Metodo no permitido.');
    }

    if (!csrf_valido()) {
        http_response_code(403);
        responderJson(false, 'La página ha caducado. Recárgala e inténtalo de nuevo.');
    }
}

/** Lee un campo de $_POST como texto (si no es texto, devuelve ""). */
function campoPost(string $nombre, bool $recortar = true): string
{
    $valor = $_POST[$nombre] ?? '';
    if (!is_string($valor)) {
        return '';
    }

    return $recortar ? trim($valor) : $valor;
}

// ------------------------------------------------------------
// LOGIN
// ------------------------------------------------------------

/**
 * Comprueba usuario/correo + contraseña.
 *
 * Acepta contraseñas modernas (password_hash) y las antiguas guardadas con
 * md5, que se actualizan automáticamente al formato nuevo al entrar.
 *
 * @return array|null ['id' => int, 'username' => string] si es correcto; null si no.
 */
function autenticarUsuario(string $identificador, string $clave): ?array
{
    $fila = obtenerUsuarioParaLogin($identificador);
    if (!$fila) {
        return null;
    }

    $guardado = (string) $fila["password_hash"];
    $correcto = false;

    if (password_verify($clave, $guardado)) {
        $correcto = true;
    } elseif (strlen($guardado) === 32 && hash_equals($guardado, md5($clave))) {
        // Contraseña antigua (md5): se acepta y se migra a password_hash.
        $correcto = true;
        actualizarPasswordHash((int) $fila["id"], password_hash($clave, PASSWORD_DEFAULT));
    }

    if (!$correcto) {
        return null;
    }

    return ['id' => (int) $fila["id"], 'username' => (string) $fila["username"]];
}

function accionLogin(): void
{
    exigirPostJson();

    $usuario = campoPost('usuario');
    $clave   = campoPost('contrasena', false);

    if ($usuario === "" || $clave === "") {
        responderJson(false, "Escribe tu usuario o correo y tu contraseña.");
    }

    $cuenta = autenticarUsuario($usuario, $clave);

    if ($cuenta) {
        // Nueva sesión segura (evita fijación de sesión)
        session_regenerate_id(true);
        $_SESSION["usuario_id"] = $cuenta["id"];
        $_SESSION["usuario"]    = $cuenta["username"];
        responderJson(true, "¡Bienvenido, " . $cuenta["username"] . "!");
    }

    responderJson(false, "Usuario o contraseña incorrectos.");
}

// ------------------------------------------------------------
// REGISTRO
// ------------------------------------------------------------

/**
 * Valida los datos del formulario de registro y crea la cuenta.
 *
 * @return array ['ok' => bool, 'mensaje' => string]
 */
function procesarRegistro(string $usuario, string $email, string $clave1, string $clave2): array
{
    if ($usuario === "" || $email === "" || $clave1 === "") {
        return ['ok' => false, 'mensaje' => "Rellena todos los campos."];
    }
    if (mb_strlen($usuario, "UTF-8") < 3) {
        return ['ok' => false, 'mensaje' => "El usuario debe tener al menos 3 caracteres."];
    }
    // Mismos límites que el formulario (maxlength): ahora también se exigen en el servidor.
    if (mb_strlen($usuario, "UTF-8") > 16) {
        return ['ok' => false, 'mensaje' => "El usuario no puede tener más de 16 caracteres."];
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email, "UTF-8") > 100) {
        return ['ok' => false, 'mensaje' => "El correo no es válido."];
    }
    if (strlen($clave1) < 4) {
        return ['ok' => false, 'mensaje' => "La contraseña debe tener al menos 4 caracteres."];
    }
    if ($clave1 !== $clave2) {
        return ['ok' => false, 'mensaje' => "Las contraseñas no coinciden."];
    }

    if (existeUsuarioOEmail($usuario, $email)) {
        return ['ok' => false, 'mensaje' => "Ese usuario o correo ya está registrado."];
    }

    if (crearUsuario($usuario, $email, password_hash($clave1, PASSWORD_DEFAULT))) {
        return ['ok' => true, 'mensaje' => "Registro completado. ¡Ya puedes iniciar sesión!"];
    }

    return ['ok' => false, 'mensaje' => "No se pudo completar el registro."];
}

function accionRegistro(): void
{
    exigirPostJson();

    $resultado = procesarRegistro(
        campoPost('usuario'),
        campoPost('email'),
        campoPost('contrasena', false),
        campoPost('confirma', false)
    );

    responderJson($resultado['ok'], $resultado['mensaje']);
}

// ------------------------------------------------------------
// LOGOUT
// ------------------------------------------------------------
function accionLogout(): void
{
    // Vaciar todas las variables de sesión.
    $_SESSION = [];

    // Eliminar la cookie de sesión del navegador.
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }

    session_destroy();
    redirigir('index.php');
}

// ------------------------------------------------------------
// SOBRES  (resultado en $_SESSION["sobre_flash"], que muestra inicio.php)
// ------------------------------------------------------------

/** Abre el sobre del día (1 carta cada 24 horas). */
function abrirSobreDelDia(int $usuario_id): array
{
    $usuario = obtenerUsuarioPorId($usuario_id);
    $faltan  = segundosRestantes($usuario["ultima_obtencion"] ?? null, ESPERA_SOBRE_DIA);

    if ($faltan > 0) {
        return [
            "tipo"    => "error",
            "mensaje" => "Ya has abierto tu sobre del día. Vuelve en unas horas.",
        ];
    }

    $azar = dinosaurioAleatorio();
    if (!$azar) {
        return [
            "tipo"    => "error",
            "mensaje" => "No hay dinosaurios disponibles.",
        ];
    }

    anadirCarta($usuario_id, (int) $azar["id"]);
    marcarUltimaObtencion($usuario_id);

    return [
        "tipo"    => "ok",
        "mensaje" => "¡Has conseguido una carta nueva!",
        "carta"   => $azar,
    ];
}

/** Abre el sobre de prueba (4 cartas, espera de 2 minutos). */
function abrirSobrePrueba(int $usuario_id): array
{
    $usuario = obtenerUsuarioPorId($usuario_id);
    $faltan  = segundosRestantes($usuario["carta_prueba"] ?? null, ESPERA_SOBRE_PRUEBA);

    if ($faltan > 0) {
        return [
            "tipo"    => "error",
            "mensaje" => "Aún no puedes abrir el sobre de prueba. Espera a que termine el contador.",
        ];
    }

    $dinos = dinosauriosAleatorios(CARTAS_SOBRE_PRUEBA);
    if (count($dinos) < CARTAS_SOBRE_PRUEBA) {
        return [
            "tipo"    => "error",
            "mensaje" => "No hay dinosaurios suficientes en el catálogo.",
        ];
    }

    anadirCartas($usuario_id, array_map(static function (array $d): int {
        return (int) $d["id"];
    }, $dinos));
    marcarCartaPrueba($usuario_id);

    return [
        "tipo"    => "ok",
        "mensaje" => "¡Has conseguido " . count($dinos) . " cartas de prueba!",
        "cartas"  => $dinos,
    ];
}

/**
 * Flujo común de los dos sobres: POST -> abrir sobre -> Redirect -> inicio.php.
 *
 * @param callable $abrirSobre abrirSobreDelDia o abrirSobrePrueba
 */
function accionSobre(callable $abrirSobre): void
{
    // Solo tiene sentido si hay sesión; si no, a la página de entrada.
    if (!esta_logueado()) {
        redirigir('index.php');
    }

    // Solo por POST.
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        redirigir('inicio.php');
    }

    if (!csrf_valido()) {
        $_SESSION["sobre_flash"] = [
            "tipo"    => "error",
            "mensaje" => "La página ha caducado. Inténtalo de nuevo.",
        ];
    } else {
        $_SESSION["sobre_flash"] = $abrirSobre((int) $_SESSION["usuario_id"]);
    }

    redirigir('inicio.php');
}

// ------------------------------------------------------------
// DISPATCH
// ------------------------------------------------------------
$accion = $_GET['accion'] ?? $_POST['accion'] ?? '';
$accion = is_string($accion) ? $accion : '';

switch ($accion) {
    case 'login':
        accionLogin();
        break;
    case 'registro':
        accionRegistro();
        break;
    case 'logout':
        accionLogout();
        break;
    case 'carta-diaria':
        accionSobre('abrirSobreDelDia');
        break;
    case 'sobre-prueba':
        accionSobre('abrirSobrePrueba');
        break;
    default:
        http_response_code(404);
        echo 'Acción no encontrada.';
}
