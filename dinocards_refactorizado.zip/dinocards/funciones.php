<?php
/**
 * funciones.php
 * ------------------------------------------------------------------
 * Arranque y utilidades comunes de DinoCards. NO contiene SQL.
 *
 *   1. Sesión con cookie endurecida.
 *   2. Manejador global de errores (detalle al log, mensaje genérico).
 *   3. Constantes y reglas de la colección (cálculos puros).
 *   4. Helpers de presentación y seguridad (escapar, login, CSRF).
 *
 * Todas las páginas y backend.php lo cargan ANTES que AccesoDatos.php.
 * ------------------------------------------------------------------
 */

// ------------------------------------------------------------
// 1. SESIÓN (cookie endurecida)
// ------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');   // rechaza ids de sesión no generados por el servidor
    ini_set('session.use_only_cookies', '1');  // nunca el id en la URL

    $es_https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $es_https,   // solo por HTTPS cuando el sitio lo usa
        'httponly' => true,        // no accesible desde JavaScript
        'samesite' => 'Lax',       // no se envía en POST desde otros sitios
    ]);
    session_start();
}

// ------------------------------------------------------------
// 2. ERRORES: detalle al log, mensaje genérico al usuario
// ------------------------------------------------------------
set_exception_handler(static function (Throwable $e): void {
    error_log(
        '[DinoCards] ' . get_class($e) . ': ' . $e->getMessage()
        . ' en ' . $e->getFile() . ':' . $e->getLine()
    );

    if (!headers_sent()) {
        http_response_code(500);
    }
    echo 'Ha ocurrido un error interno. Inténtalo de nuevo más tarde.';
    exit;
});

// ------------------------------------------------------------
// 3. CONSTANTES Y REGLAS DE LA COLECCIÓN (funciones puras)
// ------------------------------------------------------------
const ESPERA_SOBRE_DIA    = 24 * 60 * 60; // 24 horas
const ESPERA_SOBRE_PRUEBA = 120;          // 2 minutos
const CARTAS_SOBRE_PRUEBA = 4;            // cartas por sobre de prueba

/**
 * Segundos que faltan para poder repetir una acción con espera.
 * Si la fecha no existe, devuelve 0 (no hay espera).
 */
function segundosRestantes(?string $fecha, int $espera): int
{
    if ($fecha === null || $fecha === "") {
        return 0;
    }

    return max(0, $espera - (time() - strtotime($fecha)));
}

/**
 * Agrupa una lista de dinosaurio_id contando cuántas veces aparece cada uno.
 * Devuelve ['conteo' => [id => veces], 'orden' => [ids en orden de aparición]].
 */
function agruparColeccion(array $ids): array
{
    $conteo = [];
    $orden  = [];

    foreach ($ids as $id) {
        $id = (int) $id;
        if (!isset($conteo[$id])) {
            $conteo[$id] = 0;
            $orden[]     = $id;
        }
        $conteo[$id]++;
    }

    return ['conteo' => $conteo, 'orden' => $orden];
}

/** ¿El usuario tiene más de una copia de una especie? */
function esRepetida(int $veces): bool
{
    return $veces > 1;
}

/**
 * Calcula el progreso de la colección.
 * Devuelve ['especies' => int, 'total' => int, 'faltan' => int, 'porcentaje' => int].
 */
function calcularProgreso(int $especies, int $total): array
{
    $porcentaje = $total > 0 ? (int) round($especies / $total * 100) : 0;

    return [
        'especies'   => $especies,
        'total'      => $total,
        'faltan'     => max(0, $total - $especies),
        'porcentaje' => min(100, $porcentaje),
    ];
}

/** Nivel de la barra de progreso según el porcentaje (para perfil.php). */
function calcularNivel(int $porcentaje): string
{
    if ($porcentaje >= 100) {
        return "completo";
    }
    if ($porcentaje >= 70) {
        return "alto";
    }
    if ($porcentaje >= 40) {
        return "medio";
    }

    return "bajo";
}

// ------------------------------------------------------------
// 4. HELPERS DE PRESENTACIÓN Y SEGURIDAD
// ------------------------------------------------------------

/** Limpia un texto antes de mostrarlo en el HTML (evita XSS). */
function escapar($texto)
{
    return htmlspecialchars((string) ($texto ?? ""), ENT_QUOTES, "UTF-8");
}

/** Alias corto de escapar(). */
function e($texto)
{
    return escapar($texto);
}

/** Devuelve true si el usuario ha iniciado sesión. */
function esta_logueado()
{
    return isset($_SESSION["usuario_id"]);
}

/**
 * Si el usuario no ha iniciado sesión, lo manda a la página de entrada
 * (index.php) y detiene la ejecución.
 */
function pedir_login()
{
    if (!esta_logueado()) {
        header("Location: index.php");
        exit;
    }
}

/** Token CSRF de la sesión actual (se crea la primera vez que se pide). */
function csrf_token(): string
{
    if (empty($_SESSION["csrf_token"])) {
        $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
    }

    return $_SESSION["csrf_token"];
}

/** Campo oculto con el token CSRF, para meter dentro de un <form method="POST">. */
function csrf_input(): string
{
    return '<input type="hidden" name="csrf_token" value="' . escapar(csrf_token()) . '">';
}

/** ¿El POST recibido trae un token CSRF válido? */
function csrf_valido(): bool
{
    $enviado = $_POST["csrf_token"] ?? "";

    return is_string($enviado)
        && !empty($_SESSION["csrf_token"])
        && hash_equals($_SESSION["csrf_token"], $enviado);
}
